/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Serhat
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        Drug drug = new Drug();
        Scanner input = new Scanner(System.in);
        
       while(true){
           
           System.out.println("\nSelect Operation : \n1-) Add Drug \n2-)Remove Drug \n3-)Uptade Price \n4-)Search Drug \n5-) All İnformation \n6-)Exit");
           
           int operation = input.nextInt();
           if (operation<1 && operation >6) {
               System.out.println("Operation is not avaiable .... Run Again");
               break;
           }
           
           switch(operation){
               
               case 1 : drug.addDrug();break;
               case 2 :System.out.println("Enter barcode for Removing");String newbarcode = input.next() ;drug.removeDrug(newbarcode);break;
               case 3 :System.out.println("Enter barcode for Uptading price");String barcode = input.next() ;drug.uptadePrice(barcode);break;
               case 4 :System.out.println("Enter drug name for Search");String drugName = input.next() ; drug.searchDrug(drugName);break;
               case 5 : drug.information();break;
               case 6 : System.out.println("Good Bye"); break;
               
                   
                    
                       
           }
              
           
           
           
           
       }
    }
    
}
