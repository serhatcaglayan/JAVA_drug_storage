/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Serhat
 */
public class Drug {
    
    private String name , barcode;
    private int price,ammount;
    private ArrayList<Drug> drugs = new ArrayList<>();

    public Drug(String barcode, String name, int price) {
        this.name = name;
        this.barcode = barcode;
        this.price = price;
        ammount++;
        
    }

    public Drug() throws IOException {
        txtToObje();
    }
    
    
    
    public void txtToObje() throws IOException{
        
        try{
            File file = new File("C:\\Users\\Serhat\\drugList.txt");
            file.createNewFile();
            Scanner scan = new Scanner(file);
            
            while(scan.hasNext()){
                
                String str = scan.nextLine();
                
                String [] words = str.split("#");
                String barcode = words[0];
                String name = words[1];
                int price = Integer.parseInt(words[2]);
                
                Drug drug = new Drug(barcode, name, price);
                
                drugs.add(drug);
              
                
            }
            scan.close();
        }catch(FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        
        
         
        
    }
    
    
    
    
    public void addDrug(){
        
        System.out.println(" Enter drug information : \nDrug Barcode : \nDrug Name : \nDrug Price :");
        Scanner input = new Scanner(System.in);
        String barcode = input.next();
        String name = input.next();
        int price = input.nextInt();
        
        Drug drag = new Drug(barcode, name, price);
        
        drugs.add(drag);
        
        System.out.println("Drug Added ... Barcode : " + barcode);
        uptadeTxt();
        
    }
    
    public void removeDrug(String newbarcode){
        int index = 0 ;
        
        for (int i = 0; i < drugs.size(); i++) {
            
            if (newbarcode.equals(drugs.get(i).barcode) ) {
                
                
                index =i;
                
            }
            
        }
        if (!newbarcode.equals(drugs.get(index).barcode)) {
            
            System.out.println("Barcode is not match : " + newbarcode);
        }else if ( newbarcode.equals(drugs.get(index).barcode)  ){
            drugs.remove(index);
                System.out.println("Removed drug ... Barcode : " + newbarcode);
                ammount--;
        
        }
        
       
    uptadeTxt();
    
    }
    
    public void uptadePrice(String barcode){
        int index =0;
        for (int i = 0; i < drugs.size(); i++) {
            
            if (barcode.equals(drugs.get(i).barcode)) {
                index = i;
                
              
            }
        }
        
        if (!barcode.equals(drugs.get(index).barcode)) {
            
            System.out.println("Barcode is not correcct for uptadeing");
        }else if(barcode.equals(drugs.get(index).barcode)){
        
          System.out.println("Enter new price");
                Scanner input =  new Scanner(System.in);
                int newPrice = input.nextInt();
                drugs.get(index).price = newPrice;
                System.out.println("Update price ... New Price : " + newPrice);
               
        
    }
        uptadeTxt();
    }
    
    public void uptadeTxt(){
        
        try{
            File file = new File ("C:\\Users\\Serhat\\newdrugList.txt");
            PrintWriter writer = new  PrintWriter(file);
                        Scanner scan = new Scanner(file);
                        String massage ="";
            
            for (int i = 0; i < drugs.size(); i++) {
                
                 massage += drugs.get(i).barcode+"#"+drugs.get(i).name+"#"+String.valueOf(drugs.get(i).price)+"\n";
                
                }
            
            writer.print(massage);
            writer.close();
            scan.close();
            
        }catch(FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        
        
        
    }
    
    public void searchDrug(String drugName){
        int count = 0 ;
        for (int i = 0; i < drugs.size(); i++) {
            
            if (drugName.equals(drugs.get(i).name)) {
                count++;
                
            }
            
            
        }
        System.out.println("Drug Name : " + drugName + " Ammount  : " + count);
    }
    
    public void information(){
        
        System.out.println("BARCODE    NAME     PRİCE     ");
        for (int i = 0; i < drugs.size(); i++) {
            
            String massage = drugs.get(i).barcode+"       "+drugs.get(i).name+"       "+drugs.get(i).price;
            System.out.println(massage);
        }
        
        
    }

    
    
   
}
